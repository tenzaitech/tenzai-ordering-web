(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_ee23776a._.js",
  "static/chunks/node_modules_7fb35ce0._.js"
],
    source: "dynamic"
});
