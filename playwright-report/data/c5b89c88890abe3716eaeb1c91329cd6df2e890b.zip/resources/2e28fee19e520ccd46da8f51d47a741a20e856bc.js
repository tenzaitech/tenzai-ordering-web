(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_3a894c2c._.js",
  "static/chunks/_08f8aa97._.js"
],
    source: "dynamic"
});
