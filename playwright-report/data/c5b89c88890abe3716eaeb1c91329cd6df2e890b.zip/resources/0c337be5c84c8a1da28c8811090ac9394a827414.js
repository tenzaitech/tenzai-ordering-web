(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/contexts/CartContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CartProvider",
    ()=>CartProvider,
    "useCart",
    ()=>useCart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const CartContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function CartProvider({ children }) {
    _s();
    const [items, setItemsState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isHydrated, setIsHydrated] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Hydrate cart from localStorage on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartProvider.useEffect": ()=>{
            const savedCart = localStorage.getItem('tenzai_cart');
            if (savedCart) {
                try {
                    const parsed = JSON.parse(savedCart);
                    setItemsState(parsed);
                } catch (e) {
                    console.error('Failed to parse cart from localStorage:', e);
                }
            }
            // Clean up any stale editingOrderId from previous implementation
            localStorage.removeItem('tenzai_editing_order_id');
            setIsHydrated(true);
        }
    }["CartProvider.useEffect"], []);
    // Persist cart to localStorage whenever it changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartProvider.useEffect": ()=>{
            if (isHydrated) {
                localStorage.setItem('tenzai_cart', JSON.stringify(items));
            }
        }
    }["CartProvider.useEffect"], [
        items,
        isHydrated
    ]);
    const addItem = (newItem)=>{
        const id = Date.now().toString();
        setItemsState((prev)=>[
                ...prev,
                {
                    ...newItem,
                    id
                }
            ]);
    };
    const updateItem = (id, updates)=>{
        setItemsState((prev)=>prev.map((item)=>item.id === id ? {
                    ...item,
                    ...updates
                } : item));
    };
    const updateQuantity = (id, quantity)=>{
        if (quantity <= 0) {
            removeItem(id);
            return;
        }
        setItemsState((prev)=>prev.map((item)=>item.id === id ? {
                    ...item,
                    quantity
                } : item));
    };
    const removeItem = (id)=>{
        setItemsState((prev)=>prev.filter((item)=>item.id !== id));
    };
    const clearCart = ()=>{
        setItemsState([]);
    };
    const setItems = (newItems)=>{
        setItemsState(newItems);
    };
    const getTotalPrice = ()=>{
        return items.reduce((total, item)=>{
            return total + item.final_price_thb * item.quantity;
        }, 0);
    };
    const getTotalItems = ()=>{
        return items.reduce((total, item)=>total + item.quantity, 0);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CartContext.Provider, {
        value: {
            items,
            addItem,
            updateItem,
            updateQuantity,
            removeItem,
            clearCart,
            setItems,
            getTotalPrice,
            getTotalItems
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/CartContext.tsx",
        lineNumber: 112,
        columnNumber: 5
    }, this);
}
_s(CartProvider, "zU1/2qdsxrHCjnM9grzjbL1NHeM=");
_c = CartProvider;
function useCart() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CartContext);
    if (context === undefined) {
        throw new Error('useCart must be used within a CartProvider');
    }
    return context;
}
_s1(useCart, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "CartProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/i18n.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "translate",
    ()=>translate
]);
const translations = {
    th: {
        // ============================================
        // COMMON / SHARED
        // ============================================
        loading: 'กำลังโหลด...',
        pleaseWait: 'กรุณารอสักครู่...',
        retry: 'ลองใหม่',
        cancel: 'ยกเลิก',
        save: 'บันทึก',
        saving: 'กำลังบันทึก...',
        confirm: 'ยืนยัน',
        back: 'กลับ',
        close: 'ปิด',
        edit: 'แก้ไข',
        delete: 'ลบ',
        deleting: 'กำลังลบ...',
        create: 'สร้าง',
        creating: 'กำลังสร้าง...',
        updating: 'กำลังอัปเดต...',
        processing: 'กำลังดำเนินการ...',
        required: '(จำเป็น)',
        optional: '(ไม่บังคับ)',
        note: 'หมายเหตุ',
        total: 'รวมทั้งหมด',
        items: 'รายการ',
        item: 'รายการ',
        noItemsFound: 'ไม่พบรายการ',
        errorGeneric: 'เกิดข้อผิดพลาด',
        errorGenericMessage: 'ไม่สามารถดำเนินการได้',
        unauthorized: 'ไม่ได้รับอนุญาต (คีย์ผู้ดูแลหายไปหรือไม่ถูกต้อง)',
        copiedToClipboard: 'คัดลอกแล้ว',
        // ============================================
        // MENU PAGE
        // ============================================
        searchPlaceholder: 'ค้นหาเมนู...',
        recommended: 'แนะนำ',
        searchResults: 'ผลการค้นหา',
        categories: 'หมวดหมู่',
        soldOut: 'หมด',
        // ============================================
        // CART PAGE
        // ============================================
        cart: 'ตะกร้า',
        cartEmpty: 'ตะกร้าของคุณยังว่างอยู่',
        cartEmptyDesc: 'เลือกเมนูที่คุณชอบเพื่อเริ่มสั่งอาหาร',
        viewMenu: 'ดูเมนู',
        continueToCheckout: 'ดำเนินการชำระเงิน',
        addMore: 'สั่งเพิ่ม',
        // ============================================
        // CHECKOUT PAGE
        // ============================================
        checkout: 'ชำระเงิน',
        customerInfo: 'ข้อมูลลูกค้า',
        name: 'ชื่อ',
        namePlaceholder: 'กรอกชื่อของคุณ',
        phone: 'เบอร์โทร',
        phonePlaceholder: '08XXXXXXXX',
        pickupTime: 'เวลารับอาหาร',
        pickupType: 'รูปแบบรับ',
        asap: 'โดยเร็ว (ASAP)',
        asapFull: 'ให้ร้านทำทันที',
        scheduledPickup: 'กำหนดเวลารับ',
        scheduled: 'นัดเวลารับ',
        selectTime: 'เลือกเวลา',
        orderSummary: 'รายการสั่งซื้อ',
        noteToRestaurant: 'หมายเหตุถึงร้าน',
        noteToRestaurantPlaceholder: 'เช่น ไม่ใส่วาซาบิ / แพ้อาหาร / ฝากบอกพนักงาน…',
        goToPayment: 'ไปหน้าชำระเงิน',
        fillAllFields: 'กรุณากรอกข้อมูลให้ครบถ้วน',
        selectPickupTime: 'กรุณาเลือกเวลารับอาหาร',
        invalidItemsDetected: 'พบรายการที่ไม่ถูกต้อง กรุณาลบและเพิ่มรายการใหม่',
        // Processing states
        processingUploadingSlip: 'กำลังอัปโหลดสลิปการชำระเงิน… กรุณาอย่าปิดหน้านี้',
        processingCreatingOrder: 'กำลังสร้างคำสั่งซื้อ… กรุณารอสักครู่',
        processingSavingItems: 'กำลังบันทึกรายการอาหาร… ระบบกำลังตรวจสอบข้อมูลคำสั่งซื้อ',
        // Error messages - Step A (ORDER)
        errorOrderTitle: 'ทำรายการไม่สำเร็จ',
        errorOrderMessage: 'ไม่สามารถสร้างคำสั่งซื้อได้ในขณะนี้',
        errorOrderHelper: 'กรุณาตรวจสอบการเชื่อมต่ออินเทอร์เน็ต แล้วลองอีกครั้ง',
        retryOrder: 'ลองอีกครั้ง',
        backToCart: 'กลับไปตะกร้า',
        // Error messages - Step B (ITEMS)
        errorItemsTitle: 'บันทึกรายการอาหารไม่สำเร็จ',
        errorItemsMessage: 'คำสั่งซื้อถูกสร้างแล้ว แต่บันทึกรายการอาหารไม่ครบ',
        errorItemsHelper: 'กรุณาลองอีกครั้ง หากยังพบปัญหาให้ติดต่อร้านพร้อมหมายเลขคำสั่งซื้อ',
        retrySaveItems: 'ลองบันทึกอีกครั้ง',
        showOrderNumber: 'ดูหมายเลขคำสั่งซื้อ',
        // Error messages - Step C (SLIP)
        errorSlipTitle: 'อัปโหลดสลิปไม่สำเร็จ',
        errorSlipMessage: 'ระบบยังไม่ได้รับสลิปการชำระเงิน',
        errorSlipHelper: 'กรุณาลองอัปโหลดอีกครั้ง หรือเปลี่ยนไฟล์รูป',
        retryUploadSlip: 'ลองอัปโหลดอีกครั้ง',
        backToEdit: 'กลับไปแก้ไข',
        // ============================================
        // PAYMENT PAGE
        // ============================================
        payment: 'ชำระเงิน',
        promptPayInstructions: 'โอนเงินผ่าน PromptPay',
        promptPayNumber: 'หมายเลข PromptPay',
        promptPay: 'พร้อมเพย์',
        amount: 'ยอดชำระ',
        uploadSlip: 'อัปโหลดสลิป',
        uploadSlipDesc: 'กรุณาแนบหลักฐานการโอนเงิน',
        slipUploaded: 'อัปโหลดสลิปแล้ว',
        changeSlip: 'เปลี่ยนสลิป',
        confirmOrder: 'ยืนยันคำสั่งซื้อ',
        orderNotFound: 'ไม่พบคำสั่งซื้อ',
        orderNotFoundDesc: 'กรุณากลับไปหน้าชำระเงินและลองใหม่อีกครั้ง',
        backToCheckout: 'กลับไปหน้าชำระเงิน',
        orderLocked: 'ล็อคแล้ว (อัปสลิปแล้ว)',
        editItems: 'แก้ไขรายการ',
        updatingTotal: 'กำลังอัปเดตยอดรวม…',
        generatingQR: 'กำลังสร้าง QR...',
        saveQR: 'บันทึก QR',
        pleaseAttachSlip: 'กรุณาแนบสลิปการชำระเงิน',
        collapse: 'ย่อ',
        showAll: 'แสดงทั้งหมด',
        // ============================================
        // CONFIRMED PAGE
        // ============================================
        orderCreated: 'สร้างคำสั่งซื้อแล้ว',
        orderNumber: 'หมายเลขคำสั่งซื้อ',
        orderConfirmed: 'ยืนยันคำสั่งซื้อแล้ว',
        orderConfirmedDesc: 'ขอบคุณสำหรับคำสั่งซื้อ เราจะเตรียมอาหารของคุณให้',
        orderDetails: 'รายละเอียดคำสั่งซื้อ',
        pickupInfo: 'ข้อมูลการรับอาหาร',
        customerDetails: 'ข้อมูลลูกค้า',
        backToMenu: 'กลับไปหน้าเมนู',
        orderReceived: 'เราได้รับออเดอร์แล้ว',
        statusWaitingApproval: 'สถานะ: รออนุมัติ',
        viewMyOrders: 'ดูออเดอร์ของฉัน',
        couldNotLoadOrder: 'ไม่สามารถโหลดข้อมูลคำสั่งซื้อได้ กรุณาลองใหม่อีกครั้ง',
        // ============================================
        // ORDER STATUS PAGE
        // ============================================
        myOrders: 'ออเดอร์ของฉัน',
        noOrders: 'ยังไม่มีออเดอร์',
        noOrdersDesc: 'เมื่อคุณสั่งอาหาร ออเดอร์จะแสดงที่นี่',
        order: 'ออเดอร์',
        status: 'สถานะ',
        statusPending: 'รอตรวจสอบ',
        statusApproved: 'อนุมัติแล้ว',
        statusRejected: 'ปฏิเสธ',
        statusReady: 'พร้อมรับ',
        statusPickedUp: 'รับแล้ว',
        statusHintPending: 'กำลังตรวจสอบการชำระเงิน',
        statusHintApproved: 'กำลังเตรียมอาหารของคุณ',
        statusHintReady: 'พร้อมรับที่ร้านแล้ว',
        statusHintPickedUp: 'ขอบคุณที่ใช้บริการ',
        statusHintRejected: 'ติดต่อร้านหากมีข้อสงสัย',
        whatNext: 'ขั้นตอนถัดไป',
        slipNotUploaded: 'ยังไม่ได้อัปสลิป',
        orderedAt: 'สั่งเมื่อ',
        orderNotFoundDetail: 'ออเดอร์นี้ไม่พบหรือคุณไม่มีสิทธิ์เข้าถึง',
        goBack: 'กลับไปหน้าออเดอร์',
        unableToLoadOrders: 'ไม่สามารถโหลดออเดอร์ได้',
        unableToLoadData: 'ไม่สามารถโหลดข้อมูลได้',
        viewDetails: 'ดูรายละเอียด',
        editOrder: 'แก้ไขออเดอร์',
        orderMore: 'สั่งอาหารเพิ่ม',
        payUploadSlip: 'ชำระเงิน / อัปโหลดสลิป',
        backToOrders: 'กลับไปหน้าออเดอร์',
        // ============================================
        // LIFF PAGE
        // ============================================
        liffNotConfigured: 'ยังไม่ได้ตั้งค่า LIFF',
        failedToCreateSession: 'ไม่สามารถสร้างเซสชันได้',
        pleaseOpenInLine: 'กรุณาเปิดหน้านี้ใน LINE',
        openInLine: 'เปิดใน LINE',
        ifNotOpenTapHere: 'หากไม่เปิด ให้แตะที่นี่',
        connectionError: 'เชื่อมต่อไม่สำเร็จ',
        connectingLine: 'กำลังเชื่อมต่อ LINE…',
        loggingIn: 'กำลังเข้าสู่ระบบ…',
        liffInstructionsIOS: 'แตะ "เปิดใน LINE" ด้านล่าง หากมีการถาม ให้เลือก "เปิด"',
        liffInstructionsAndroid: 'แตะ "เปิดใน LINE" ด้านล่าง หากมีการถาม ให้อนุญาตเปิดใน LINE',
        liffInstructionsDesktop: 'กรุณาเปิดลิงก์นี้บนโทรศัพท์ในแอป LINE',
        addFriendRequired: 'เพิ่มเพื่อนเพื่อดำเนินการต่อ',
        addFriendDescription: 'กรุณาเพิ่ม Official Account เป็นเพื่อนเพื่อใช้บริการสั่งอาหาร',
        addFriend: 'เพิ่มเพื่อน',
        // ============================================
        // CLOSED PAGE
        // ============================================
        shopClosedTitle: 'ร้านปิดรับออเดอร์ชั่วคราว',
        shopClosedMessage: 'ขออภัยในความไม่สะดวกครับ\n\nสามารถดูเมนูได้ที่ปุ่ม MENU\nในหน้าแชท LINE ของร้าน',
        // ============================================
        // ITEM DETAIL PAGE
        // ============================================
        itemDetails: 'รายละเอียดสินค้า',
        editItem: 'แก้ไขรายการ',
        addItem: 'เพิ่มรายการ',
        specialInstructions: 'คำขอพิเศษ',
        specialInstructionsPlaceholder: 'เพิ่มคำขอพิเศษที่นี่ (ถ้ามี)',
        quantity: 'จำนวน',
        saveChanges: 'บันทึกการเปลี่ยนแปลง',
        addToCart: 'เพิ่มลงตะกร้า',
        addToOrder: 'เพิ่มลงออเดอร์',
        itemUpdated: 'แก้ไขรายการแล้ว',
        addedToCart: 'เพิ่มลงตะกร้าแล้ว',
        pleaseSelect: 'กรุณาเลือก',
        selectAtLeast: 'กรุณาเลือกอย่างน้อย',
        adding: 'กำลังเพิ่ม...',
        failedToAddItem: 'เพิ่มรายการไม่สำเร็จ',
        // ============================================
        // ADMIN NAVIGATION
        // ============================================
        dashboard: 'แดชบอร์ด',
        orders: 'คำสั่งซื้อ',
        staff: 'พนักงาน',
        menu: 'เมนู',
        category: 'หมวดหมู่',
        options: 'ตัวเลือก',
        importExport: 'นำเข้า/ส่งออก',
        imageImport: 'นำเข้ารูปภาพ',
        settings: 'ตั้งค่า',
        // ============================================
        // ADMIN DASHBOARD
        // ============================================
        operations: 'การดำเนินงาน',
        restaurantManagement: 'การจัดการร้านอาหาร',
        ordersDesc: 'ดูและจัดการคำสั่งซื้อ',
        menuDesc: 'รายการ ราคา และความพร้อมจำหน่าย',
        categoriesDesc: 'จัดระเบียบโครงสร้างเมนู',
        optionsDesc: 'การปรับแต่งและส่วนเสริม',
        importExportDesc: 'การจัดการข้อมูลจำนวนมาก',
        imageImportDesc: 'นำเข้ารูปภาพอาหารอัตโนมัติ',
        // ============================================
        // ADMIN ORDERS PAGE
        // ============================================
        adminOrders: 'ผู้ดูแล - คำสั่งซื้อ',
        loadingOrders: 'กำลังโหลดคำสั่งซื้อ...',
        orderAccepting: 'การรับคำสั่งซื้อ',
        open: 'เปิด',
        closed: 'ปิด',
        customersCanOrder: 'ลูกค้าสามารถสั่งอาหารได้',
        customersBlocked: 'ลูกค้าไม่สามารถสั่งอาหารได้',
        closeShop: 'ปิดร้าน',
        openShop: 'เปิดร้าน',
        customer: 'ลูกค้า',
        pickup: 'รับสินค้า',
        noOrdersFound: 'ไม่พบคำสั่งซื้อ',
        immediate: 'ทันที',
        filterStatus: 'สถานะ',
        filterDate: 'วันที่',
        filterAll: 'ทั้งหมด',
        filterToday: 'วันนี้',
        filterPending: 'รอดำเนินการ',
        filterApproved: 'อนุมัติแล้ว',
        filterRejected: 'ปฏิเสธแล้ว',
        filterReady: 'พร้อมรับ',
        filterPickedUp: 'รับแล้ว',
        search: 'ค้นหา',
        searchPlaceholderAdmin: 'เลขออเดอร์, ชื่อ, เบอร์โทร...',
        showing: 'แสดง',
        of: 'จาก',
        prev: 'ก่อนหน้า',
        next: 'ถัดไป',
        page: 'หน้า',
        created: 'สร้างเมื่อ',
        totalAmount: 'ยอดรวม',
        paymentSlip: 'สลิปการชำระเงิน',
        openSlip: 'ดูสลิป',
        noSlipUploaded: 'ยังไม่ได้อัปโหลดสลิป',
        customerNote: 'หมายเหตุจากลูกค้า',
        orderItems: 'รายการสั่งซื้อ',
        approve: 'อนุมัติ',
        reject: 'ปฏิเสธ',
        confirmApprove: 'อนุมัติคำสั่งซื้อนี้และแจ้งทีมครัว?',
        confirmOpenShop: 'เปิดรับออเดอร์อีกครั้ง?',
        confirmCloseShop: 'ปิดรับออเดอร์ชั่วคราว?',
        shopOpened: 'เปิดรับออเดอร์แล้ว',
        shopClosed: 'ปิดรับออเดอร์แล้ว',
        orderApprovedSuccess: 'อนุมัติคำสั่งซื้อสำเร็จ',
        orderApprovedError: 'ไม่สามารถอนุมัติคำสั่งซื้อได้',
        orderRejectedSuccess: 'ปฏิเสธคำสั่งซื้อสำเร็จ',
        orderRejectedError: 'ไม่สามารถปฏิเสธคำสั่งซื้อได้',
        rejectOrder: 'ปฏิเสธคำสั่งซื้อ',
        rejectReasonOptional: 'เหตุผล (ไม่บังคับ)',
        rejectReasonPlaceholder: 'เช่น สินค้าหมด, การชำระเงินไม่ถูกต้อง...',
        confirmReject: 'ยืนยันปฏิเสธ',
        // ============================================
        // ADMIN SETTINGS PAGE
        // ============================================
        systemSettings: 'ตั้งค่าระบบ',
        loadingSettings: 'กำลังโหลดการตั้งค่า...',
        promptPayIdLabel: 'หมายเลข PromptPay',
        promptPayIdDesc: 'เบอร์โทรหรือเลขบัตรประชาชนสำหรับรับเงินผ่าน PromptPay',
        promptPayIdFormat: 'รูปแบบ: 0XXXXXXXXX (10 หลัก) หรือเลขบัตรประชาชน 13 หลัก',
        lineApproverIdLabel: 'LINE Approver ID',
        lineApproverIdDesc: 'LINE User ID ที่จะได้รับแจ้งเตือนออเดอร์ใหม่ (สำหรับอนุมัติ)',
        lineStaffIdLabel: 'LINE Staff ID',
        lineStaffIdDesc: 'LINE User/Group ID ที่จะได้รับแจ้งเตือนออเดอร์ที่อนุมัติแล้ว (พนักงานครัว)',
        changeStaffPin: 'เปลี่ยน Staff PIN',
        changeStaffPinDesc: 'PIN 4 หลักสำหรับเข้าใช้งาน Staff Board',
        changeStaffPinWarning: 'การเปลี่ยน PIN จะทำให้พนักงานทั้งหมดต้องเข้าสู่ระบบใหม่',
        leaveEmptyToKeepPin: 'เว้นว่างเพื่อใช้ PIN เดิม',
        test: 'ทดสอบ',
        sending: 'กำลังส่ง...',
        noChanges: 'ไม่มีการเปลี่ยนแปลง',
        saveSettings: 'บันทึกการตั้งค่า',
        settingsSaved: 'บันทึกการตั้งค่าสำเร็จ!',
        settingsSavedWithPin: 'บันทึกการตั้งค่าสำเร็จ! PIN ถูกเปลี่ยน - พนักงานทั้งหมดจะต้องเข้าสู่ระบบใหม่',
        failedToLoadSettings: 'โหลดการตั้งค่าไม่สำเร็จ',
        failedToSaveSettings: 'บันทึกการตั้งค่าไม่สำเร็จ',
        adminAccessRequired: 'ต้องมีสิทธิ์ Admin กรุณาเข้าผ่าน /admin/menu ก่อน',
        pinMustBe4Digits: 'PIN ต้องเป็นตัวเลข 4 หลัก',
        noChangesToSave: 'ไม่มีการเปลี่ยนแปลงที่จะบันทึก',
        testMessageSent: 'ส่งข้อความทดสอบสำเร็จ!',
        failedToSendTestMessage: 'ส่งข้อความทดสอบไม่สำเร็จ',
        // ============================================
        // ADMIN MENU MANAGEMENT
        // ============================================
        menuManagement: 'การจัดการเมนู',
        createNewItem: '+ สร้างรายการใหม่',
        searchByNameOrCode: 'ค้นหาด้วยชื่อหรือรหัส...',
        allCategories: 'หมวดหมู่ทั้งหมด',
        noMenuItemsFound: 'ไม่พบรายการเมนู',
        tryAdjustingFilters: 'ลองปรับการค้นหาหรือตัวกรอง',
        getStartedByCreating: 'เริ่มต้นด้วยการสร้างรายการเมนูแรกของคุณ',
        createFirstMenuItem: '+ สร้างรายการเมนูแรก',
        image: 'รูปภาพ',
        code: 'รหัส',
        nameTh: 'ชื่อ (ไทย)',
        nameEn: 'ชื่อ (อังกฤษ)',
        price: 'ราคา',
        updated: 'อัปเดต',
        noImage: 'ไม่มีรูป',
        active: 'ใช้งาน',
        inactive: 'ไม่ใช้งาน',
        setInactive: 'ตั้งเป็นไม่ใช้งาน',
        setActive: 'ตั้งเป็นใช้งาน',
        menuActivated: 'เปิดใช้งานเมนูแล้ว',
        menuDeactivated: 'ปิดใช้งานเมนูแล้ว',
        failedToToggle: 'ไม่สามารถเปลี่ยนสถานะได้',
        deleteMenuItem: 'ลบรายการเมนู',
        confirmDeleteMenu: 'คุณแน่ใจหรือไม่ว่าต้องการลบ',
        actionCannotBeUndone: 'การดำเนินการนี้ไม่สามารถยกเลิกได้',
        menuItemDeleted: 'ลบรายการเมนูแล้ว',
        // ============================================
        // ADMIN CATEGORY MANAGEMENT
        // ============================================
        categoryManagement: 'การจัดการหมวดหมู่',
        createCategory: '+ สร้างหมวดหมู่',
        createNewCategory: 'สร้างหมวดหมู่ใหม่',
        enterCategoryName: 'ป้อนชื่อหมวดหมู่...',
        categoryNameRequired: 'ต้องระบุชื่อหมวดหมู่',
        categoryCreated: 'สร้างหมวดหมู่แล้ว',
        categoryUpdated: 'อัปเดตหมวดหมู่แล้ว',
        categoryDeleted: 'ลบหมวดหมู่แล้ว',
        menuItems: 'รายการเมนู',
        actions: 'การดำเนินการ',
        noCategoriesFound: 'ไม่พบหมวดหมู่',
        getStartedByCreatingCategory: 'เริ่มต้นด้วยการสร้างหมวดหมู่แรกของคุณ',
        createFirstCategory: '+ สร้างหมวดหมู่แรก',
        rename: 'เปลี่ยนชื่อ',
        cannotDeleteCategory: 'ไม่สามารถลบหมวดหมู่: มีรายการเมนู',
        deleteCategory: 'ลบหมวดหมู่',
        // ============================================
        // STAGE 1 NEW FEATURES
        // ============================================
        popular: 'ยอดนิยม',
        addedToPopular: 'เพิ่มในเมนูยอดนิยมแล้ว',
        removedFromPopular: 'นำออกจากเมนูยอดนิยมแล้ว',
        changeCategory: 'เปลี่ยนหมวดหมู่',
        categoryChanged: 'เปลี่ยนหมวดหมู่แล้ว',
        visible: 'แสดง',
        hidden: 'ซ่อน',
        saveVisibility: 'บันทึกการแสดงผล',
        visibilitySaved: 'บันทึกการแสดงผลแล้ว',
        changesSaved: 'บันทึกการเปลี่ยนแปลงแล้ว'
    },
    en: {
        // ============================================
        // COMMON / SHARED
        // ============================================
        loading: 'Loading...',
        pleaseWait: 'Please wait...',
        retry: 'Retry',
        cancel: 'Cancel',
        save: 'Save',
        saving: 'Saving...',
        confirm: 'Confirm',
        back: 'Back',
        close: 'Close',
        edit: 'Edit',
        delete: 'Delete',
        deleting: 'Deleting...',
        create: 'Create',
        creating: 'Creating...',
        updating: 'Updating...',
        processing: 'Processing...',
        required: '(required)',
        optional: '(Optional)',
        note: 'Note',
        total: 'Total',
        items: 'items',
        item: 'item',
        noItemsFound: 'No items found',
        errorGeneric: 'Error',
        errorGenericMessage: 'Unable to process request',
        unauthorized: 'Unauthorized (admin key missing/invalid)',
        copiedToClipboard: 'Copied',
        // ============================================
        // MENU PAGE
        // ============================================
        searchPlaceholder: 'Search menu...',
        recommended: 'Recommended',
        searchResults: 'Search Results',
        categories: 'Categories',
        soldOut: 'Sold out',
        // ============================================
        // CART PAGE
        // ============================================
        cart: 'Cart',
        cartEmpty: 'Your cart is empty',
        cartEmptyDesc: 'Choose your favorite menu to start ordering',
        viewMenu: 'View Menu',
        continueToCheckout: 'Continue to Checkout',
        addMore: 'Add more',
        // ============================================
        // CHECKOUT PAGE
        // ============================================
        checkout: 'Checkout',
        customerInfo: 'Customer Information',
        name: 'Name',
        namePlaceholder: 'Enter your name',
        phone: 'Phone',
        phonePlaceholder: '08XXXXXXXX',
        pickupTime: 'Pickup Time',
        pickupType: 'Pickup Type',
        asap: 'ASAP',
        asapFull: 'Prepare immediately',
        scheduledPickup: 'Scheduled Pickup',
        scheduled: 'Scheduled',
        selectTime: 'Select Time',
        orderSummary: 'Order Summary',
        noteToRestaurant: 'Note to Restaurant',
        noteToRestaurantPlaceholder: 'e.g. No wasabi / Allergies / Special instructions…',
        goToPayment: 'Go to Payment',
        fillAllFields: 'Please fill in all required fields',
        selectPickupTime: 'Please select pickup time',
        invalidItemsDetected: 'Invalid items detected. Please remove and re-add them.',
        // Processing states
        processingUploadingSlip: 'Uploading payment slip… Please do not close this page',
        processingCreatingOrder: 'Creating order… Please wait',
        processingSavingItems: 'Saving items… Validating order data',
        // Error messages - Step A (ORDER)
        errorOrderTitle: 'Order Failed',
        errorOrderMessage: 'Unable to create order at this time',
        errorOrderHelper: 'Please check your internet connection and try again',
        retryOrder: 'Try Again',
        backToCart: 'Back to Cart',
        // Error messages - Step B (ITEMS)
        errorItemsTitle: 'Failed to Save Items',
        errorItemsMessage: 'Order was created but items were not saved completely',
        errorItemsHelper: 'Please try again. If the problem persists, contact us with your order number',
        retrySaveItems: 'Try Saving Again',
        showOrderNumber: 'Show Order Number',
        // Error messages - Step C (SLIP)
        errorSlipTitle: 'Slip Upload Failed',
        errorSlipMessage: 'Payment slip was not received',
        errorSlipHelper: 'Please try uploading again or change the image file',
        retryUploadSlip: 'Try Uploading Again',
        backToEdit: 'Back to Edit',
        // ============================================
        // PAYMENT PAGE
        // ============================================
        payment: 'Payment',
        promptPayInstructions: 'Transfer via PromptPay',
        promptPayNumber: 'PromptPay Number',
        promptPay: 'PromptPay',
        amount: 'Amount',
        uploadSlip: 'Upload Slip',
        uploadSlipDesc: 'Please attach payment proof',
        slipUploaded: 'Slip uploaded',
        changeSlip: 'Change slip',
        confirmOrder: 'Confirm Order',
        orderNotFound: 'Order Not Found',
        orderNotFoundDesc: 'Please go back to checkout and try again',
        backToCheckout: 'Back to Checkout',
        orderLocked: 'Locked (slip uploaded)',
        editItems: 'Edit Items',
        updatingTotal: 'Updating total…',
        generatingQR: 'Generating QR...',
        saveQR: 'Save QR',
        pleaseAttachSlip: 'Please attach payment slip',
        collapse: 'Collapse',
        showAll: 'Show all',
        // ============================================
        // CONFIRMED PAGE
        // ============================================
        orderCreated: 'Order created',
        orderNumber: 'Order Number',
        orderConfirmed: 'Order Confirmed',
        orderConfirmedDesc: 'Thank you for your order. We will prepare your food',
        orderDetails: 'Order Details',
        pickupInfo: 'Pickup Information',
        customerDetails: 'Customer Details',
        backToMenu: 'Back to Menu',
        orderReceived: 'We received your order',
        statusWaitingApproval: 'Status: Waiting for approval',
        viewMyOrders: 'View My Orders',
        couldNotLoadOrder: 'Could not load order information. Please try again',
        // ============================================
        // ORDER STATUS PAGE
        // ============================================
        myOrders: 'My Orders',
        noOrders: 'No orders yet',
        noOrdersDesc: 'When you place an order, it will appear here',
        order: 'Order',
        status: 'Status',
        statusPending: 'Pending',
        statusApproved: 'Approved',
        statusRejected: 'Rejected',
        statusReady: 'Ready',
        statusPickedUp: 'Picked Up',
        statusHintPending: 'Verifying your payment',
        statusHintApproved: 'Preparing your order',
        statusHintReady: 'Ready for pickup',
        statusHintPickedUp: 'Thank you for your order',
        statusHintRejected: 'Contact us if you have questions',
        whatNext: "What's next",
        slipNotUploaded: 'Slip not uploaded',
        orderedAt: 'Ordered at',
        orderNotFoundDetail: 'This order was not found or you do not have access.',
        goBack: 'Go Back',
        unableToLoadOrders: 'Unable to load orders',
        unableToLoadData: 'Unable to load data',
        viewDetails: 'View Details',
        editOrder: 'Edit Order',
        orderMore: 'Order More',
        payUploadSlip: 'Pay / Upload Slip',
        backToOrders: 'Back to Orders',
        // ============================================
        // LIFF PAGE
        // ============================================
        liffNotConfigured: 'LIFF ID not configured',
        failedToCreateSession: 'Failed to create session',
        pleaseOpenInLine: 'Please open this page in LINE',
        openInLine: 'Open in LINE',
        ifNotOpenTapHere: 'If it doesn\'t open, tap here',
        connectionError: 'Connection Error',
        connectingLine: 'Connecting LINE…',
        loggingIn: 'Logging in…',
        liffInstructionsIOS: 'Tap "Open in LINE" below. If prompted, choose "Open".',
        liffInstructionsAndroid: 'Tap "Open in LINE" below. If prompted, allow opening in LINE.',
        liffInstructionsDesktop: 'Please open this link on your phone in the LINE app.',
        addFriendRequired: 'Please add us as a friend to continue',
        addFriendDescription: 'Please add our Official Account to use the food ordering service',
        addFriend: 'Add Friend',
        // ============================================
        // CLOSED PAGE
        // ============================================
        shopClosedTitle: 'Shop is temporarily closed',
        shopClosedMessage: 'We apologize for the inconvenience.\n\nYou can view the menu using the MENU button\nin the LINE chat.',
        // ============================================
        // ITEM DETAIL PAGE
        // ============================================
        itemDetails: 'Item Details',
        editItem: 'Edit Item',
        addItem: 'Add Item',
        specialInstructions: 'Special Instructions',
        specialInstructionsPlaceholder: 'Add any special requests here (optional)',
        quantity: 'Quantity',
        saveChanges: 'Save Changes',
        addToCart: 'Add to Cart',
        addToOrder: 'Add to Order',
        itemUpdated: 'Item updated',
        addedToCart: 'Added to cart',
        pleaseSelect: 'Please select',
        selectAtLeast: 'Select at least',
        adding: 'Adding...',
        failedToAddItem: 'Failed to add item',
        // ============================================
        // ADMIN NAVIGATION
        // ============================================
        dashboard: 'Dashboard',
        orders: 'Orders',
        staff: 'Staff',
        menu: 'Menu',
        category: 'Category',
        options: 'Options',
        importExport: 'Import/Export',
        imageImport: 'Image Import',
        settings: 'Settings',
        // ============================================
        // ADMIN DASHBOARD
        // ============================================
        operations: 'Operations',
        restaurantManagement: 'Restaurant management',
        ordersDesc: 'View and manage customer orders',
        menuDesc: 'Items, prices, and availability',
        categoriesDesc: 'Organize menu structure',
        optionsDesc: 'Customizations and add-ons',
        importExportDesc: 'Bulk data operations',
        imageImportDesc: 'Auto-import menu item images',
        // ============================================
        // ADMIN ORDERS PAGE
        // ============================================
        adminOrders: 'Admin - Orders',
        loadingOrders: 'Loading orders...',
        orderAccepting: 'Order Accepting',
        open: 'OPEN',
        closed: 'CLOSED',
        customersCanOrder: 'Customers can place orders',
        customersBlocked: 'Customers are blocked from ordering',
        closeShop: 'Close Shop',
        openShop: 'Open Shop',
        customer: 'Customer',
        pickup: 'Pickup',
        noOrdersFound: 'No orders found',
        immediate: 'ASAP',
        filterStatus: 'Status',
        filterDate: 'Date',
        filterAll: 'All',
        filterToday: 'Today',
        filterPending: 'Pending',
        filterApproved: 'Approved',
        filterRejected: 'Rejected',
        filterReady: 'Ready',
        filterPickedUp: 'Picked Up',
        search: 'Search',
        searchPlaceholderAdmin: 'Order #, name, phone...',
        showing: 'Showing',
        of: 'of',
        prev: 'Prev',
        next: 'Next',
        page: 'Page',
        created: 'Created',
        totalAmount: 'Total Amount',
        paymentSlip: 'Payment Slip',
        openSlip: 'Open Slip',
        noSlipUploaded: 'No slip uploaded',
        customerNote: 'Customer Note',
        orderItems: 'Order Items',
        approve: 'Approve',
        reject: 'Reject',
        confirmApprove: 'Approve this order and notify kitchen?',
        confirmOpenShop: 'Open shop for orders?',
        confirmCloseShop: 'Temporarily close shop?',
        shopOpened: 'Shop is now open',
        shopClosed: 'Shop is now closed',
        orderApprovedSuccess: 'Order approved successfully',
        orderApprovedError: 'Failed to approve order',
        orderRejectedSuccess: 'Order rejected successfully',
        orderRejectedError: 'Failed to reject order',
        rejectOrder: 'Reject Order',
        rejectReasonOptional: 'Reason (optional)',
        rejectReasonPlaceholder: 'e.g., Out of stock, Invalid payment...',
        confirmReject: 'Confirm Reject',
        // ============================================
        // ADMIN SETTINGS PAGE
        // ============================================
        systemSettings: 'System Settings',
        loadingSettings: 'Loading settings...',
        promptPayIdLabel: 'PromptPay ID',
        promptPayIdDesc: 'Phone number or National ID for receiving PromptPay payments.',
        promptPayIdFormat: 'Format: 0XXXXXXXXX (10 digits) or 13-digit National ID',
        lineApproverIdLabel: 'LINE Approver ID',
        lineApproverIdDesc: 'LINE User ID that receives new order notifications (for payment approval).',
        lineStaffIdLabel: 'LINE Staff ID',
        lineStaffIdDesc: 'LINE User/Group ID that receives approved order notifications (kitchen staff).',
        changeStaffPin: 'Change Staff PIN',
        changeStaffPinDesc: '4-digit PIN for staff board access.',
        changeStaffPinWarning: 'Changing PIN will log out all staff on their next request.',
        leaveEmptyToKeepPin: 'Leave empty to keep current PIN',
        test: 'Test',
        sending: 'Sending...',
        noChanges: 'No Changes',
        saveSettings: 'Save Settings',
        settingsSaved: 'Settings saved successfully!',
        settingsSavedWithPin: 'Settings saved! Staff PIN changed - all staff sessions will be invalidated.',
        failedToLoadSettings: 'Failed to load settings',
        failedToSaveSettings: 'Failed to save settings',
        adminAccessRequired: 'Admin access required. Please access via /admin/menu first.',
        pinMustBe4Digits: 'PIN must be exactly 4 digits',
        noChangesToSave: 'No changes to save',
        testMessageSent: 'Test message sent!',
        failedToSendTestMessage: 'Failed to send test message',
        // ============================================
        // ADMIN MENU MANAGEMENT
        // ============================================
        menuManagement: 'Menu Management',
        createNewItem: '+ Create New Item',
        searchByNameOrCode: 'Search by name or code...',
        allCategories: 'All Categories',
        noMenuItemsFound: 'No menu items found',
        tryAdjustingFilters: 'Try adjusting your search or filters',
        getStartedByCreating: 'Get started by creating your first menu item',
        createFirstMenuItem: '+ Create First Menu Item',
        image: 'Image',
        code: 'Code',
        nameTh: 'Name (TH)',
        nameEn: 'Name (EN)',
        price: 'Price',
        updated: 'Updated',
        noImage: 'No image',
        active: 'Active',
        inactive: 'Inactive',
        setInactive: 'Set Inactive',
        setActive: 'Set Active',
        menuActivated: 'Menu activated successfully',
        menuDeactivated: 'Menu deactivated successfully',
        failedToToggle: 'Failed to toggle active status',
        deleteMenuItem: 'Delete Menu Item',
        confirmDeleteMenu: 'Are you sure you want to delete',
        actionCannotBeUndone: 'This action cannot be undone',
        menuItemDeleted: 'Menu item deleted successfully',
        // ============================================
        // ADMIN CATEGORY MANAGEMENT
        // ============================================
        categoryManagement: 'Category Management',
        createCategory: '+ Create Category',
        createNewCategory: 'Create New Category',
        enterCategoryName: 'Enter category name...',
        categoryNameRequired: 'Category name is required',
        categoryCreated: 'Category created successfully',
        categoryUpdated: 'Category updated successfully',
        categoryDeleted: 'Category deleted successfully',
        menuItems: 'Menu Items',
        actions: 'Actions',
        noCategoriesFound: 'No categories found',
        getStartedByCreatingCategory: 'Get started by creating your first category',
        createFirstCategory: '+ Create First Category',
        rename: 'Rename',
        cannotDeleteCategory: 'Cannot delete category: menu items are using this category',
        deleteCategory: 'Delete Category',
        // ============================================
        // STAGE 1 NEW FEATURES
        // ============================================
        popular: 'Popular',
        addedToPopular: 'Added to popular',
        removedFromPopular: 'Removed from popular',
        changeCategory: 'Change category',
        categoryChanged: 'Category changed',
        visible: 'Visible',
        hidden: 'Hidden',
        saveVisibility: 'Save Visibility',
        visibilitySaved: 'Visibility saved',
        changesSaved: 'Changes saved'
    }
};
function translate(key, language) {
    return translations[language][key] || translations.th[key] || key;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LanguageProvider",
    ()=>LanguageProvider,
    "useLanguage",
    ()=>useLanguage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const LanguageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function LanguageProvider({ children, scope = 'customer' }) {
    _s();
    const storageKey = scope === 'customer' ? 'tenzai:customer-locale' : 'tenzai:admin-locale';
    const [language, setLanguageState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('th');
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LanguageProvider.useEffect": ()=>{
            const stored = localStorage.getItem(storageKey);
            const initialLanguage = stored || 'th';
            setLanguageState(initialLanguage);
            setMounted(true);
        }
    }["LanguageProvider.useEffect"], [
        storageKey
    ]);
    const setLanguage = (lang)=>{
        setLanguageState(lang);
        localStorage.setItem(storageKey, lang);
    };
    const t = (key)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["translate"])(key, language);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LanguageContext.Provider, {
        value: {
            language,
            setLanguage,
            t
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/LanguageContext.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
_s(LanguageProvider, "9Nyvc23RbEUtKo4poS1WAm3lDSU=");
_c = LanguageProvider;
function useLanguage() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LanguageContext);
    if (context === undefined) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
}
_s1(useLanguage, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "LanguageProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/contexts/CheckoutContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CheckoutProvider",
    ()=>CheckoutProvider,
    "useCheckout",
    ()=>useCheckout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const defaultDraft = {
    customerName: '',
    customerPhone: '',
    pickupType: 'ASAP',
    pickupDate: '',
    pickupTime: '',
    note: '',
    customerNote: ''
};
const CheckoutContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function CheckoutProvider({ children }) {
    _s();
    const [draft, setDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultDraft);
    const [activeOrderId, setActiveOrderId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [lastSyncedCartFingerprint, setLastSyncedCartFingerprint] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const updateDraft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CheckoutProvider.useCallback[updateDraft]": (updates)=>{
            setDraft({
                "CheckoutProvider.useCallback[updateDraft]": (prev)=>{
                    // Shallow equality check to prevent unnecessary updates
                    let hasChanges = false;
                    for(const key in updates){
                        if (prev[key] !== updates[key]) {
                            hasChanges = true;
                            break;
                        }
                    }
                    if (!hasChanges) return prev;
                    return {
                        ...prev,
                        ...updates
                    };
                }
            }["CheckoutProvider.useCallback[updateDraft]"]);
        }
    }["CheckoutProvider.useCallback[updateDraft]"], []);
    const clearDraft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CheckoutProvider.useCallback[clearDraft]": ()=>{
            setDraft(defaultDraft);
            setActiveOrderId(null);
            setLastSyncedCartFingerprint(null);
        }
    }["CheckoutProvider.useCallback[clearDraft]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CheckoutContext.Provider, {
        value: {
            draft,
            updateDraft,
            clearDraft,
            activeOrderId,
            setActiveOrderId,
            lastSyncedCartFingerprint,
            setLastSyncedCartFingerprint
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/CheckoutContext.tsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
_s(CheckoutProvider, "YrMEL2EDZmh24DKHUwq/hXDJ8Mc=");
_c = CheckoutProvider;
function useCheckout() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CheckoutContext);
    if (context === undefined) {
        throw new Error('useCheckout must be used within a CheckoutProvider');
    }
    return context;
}
_s1(useCheckout, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "CheckoutProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ "use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
            case REACT_VIEW_TRANSITION_TYPE:
                return "ViewTransition";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
    }
    function isValidElement(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    var React = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        if (trackActualOwner) {
            var previousStackTraceLimit = Error.stackTraceLimit;
            Error.stackTraceLimit = 10;
            var debugStackDEV = Error("react-stack-top-frame");
            Error.stackTraceLimit = previousStackTraceLimit;
        } else debugStackDEV = unknownOwnerDebugStack;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStackDEV, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
]);

//# sourceMappingURL=_7194c19d._.js.map